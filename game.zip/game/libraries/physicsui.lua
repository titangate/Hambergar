IntereactMap = Map:subclass'IntereactMap'

function IntereactMap:initialize(...)
	super.initialize(self,...)
	self.followerbody = 