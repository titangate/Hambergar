local thisthread = love.thread.getThread('loadingthread' )
local name = thisthread:receive
t_loadedimage