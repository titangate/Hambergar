require 'objectlua.bootstrap'
require 'objectlua.Class'
require 'objectlua.Object'
