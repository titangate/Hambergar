--
--
--

require 'TraitTransformation'


TraitExclusion = TraitTransformation:subclass()

function TraitExclusion:collectMethodsForSymbolInto(aSymbol)
end
