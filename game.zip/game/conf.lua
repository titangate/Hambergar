function love.conf(t)
	t.title = "Hambergar -- ring0dev 2011"
	t.author = "Leon Jiang"
	t.console = true
	t.screen.width = 1024
	t.screen.height = 600
end