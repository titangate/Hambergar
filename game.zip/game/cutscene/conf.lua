function love.conf(t)
	t.screen.width = 1024
	t.screen.height = 800
end